
# Flag Capture

```{figure} ../_static/videos/multi-agent-environments/flag_capture.gif
:width: 140px
:name: flag_capture
```

This environment is part of the <a href='..'>Atari environments</a>. Please read that page first for general information.

| Import               | `from pettingzoo.atari import flag_capture_v2` |
|----------------------|------------------------------------------------|
| Actions              | Discrete                                       |
| Parallel API         | Yes                                            |
| Manual Control       | No                                             |
| Agents               | `agents= ['first_0', 'second_0']`              |
| Agents               | 2                                              |
| Action Shape         | (1,)                                           |
| Action Values        | [0,9]                                          |
| Observation Shape    | (210, 160, 3)                                  |
| Observation Values   | (0,255)                                        |

A battle of memory and information. A flag is hidden on the map. You can travel through the map and check the squares in it. If it is the flag, you score a point (and your opponent is penalized). If it is a bomb, you get sent back to your starting location. Otherwise, it will give you a hint to where the flag is, either a direction or a distance. Your player needs to be able to use information from both your own search and your opponent's search in order to narrow down the location of the flag quickly and effectively.

[Official flag capture manual](https://atariage.com/manual_html_page.php?SoftwareLabelID=183)

## Environment parameters

Environment parameters are common to all Atari environments and are described in the [base multi-agent environment documentation](../multi-agent-environments).

## Action Space (Minimal)

In any given turn, an agent can choose from one of 10 actions.

| Value | Meaning    | Value | Meaning  | Value | Meaning     |
|-------|------------|-------|----------|-------|-------------|
| `0`   | `NOOP`     | `1`   | `FIRE`   | `2`   | `UP`        |
| `3`   | `RIGHT`    | `4`   | `LEFT`   | `5`   | `DOWN`      |
| `6`   | `UPRIGHT`  | `7`   | `UPLEFT` | `8`   | `DOWNRIGHT` |
| `9`   | `DOWNLEFT` |       |          |       |             |

See [environment specification](../env-spec) to see more information on the action meaning.

## Version History

* v2: Minimal Action Space (1.18.0)
* v1: Breaking changes to entire API (1.4.0)
* v0: Initial versions release (1.0.0)
